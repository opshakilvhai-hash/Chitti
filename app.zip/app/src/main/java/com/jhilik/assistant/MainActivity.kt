package com.jhilik.assistant

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var stt: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var fileCb: ValueCallback<Array<Uri>>? = null

    private fun js(code: String) = runOnUiThread { web.evaluateJavascript(code, null) }
    private fun emit(t: String, x: String = "") =
        js("window.__native&&window.__native(" + JSONObject.quote(t) + "," + JSONObject.quote(x) + ")")

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS), 1)
        tts = TextToSpeech(this) { ttsReady = it == TextToSpeech.SUCCESS }
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = false
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView?, r: WebResourceRequest?): WebResourceResponse? =
                loader.shouldInterceptRequest(r!!.url)

            override fun shouldOverrideUrlLoading(v: WebView?, r: WebResourceRequest?): Boolean {
                val u = r!!.url
                if (u.host == "appassets.androidplatform.net") return false
                try { startActivity(Intent(Intent.ACTION_VIEW, u)) } catch (_: Exception) {}
                return true
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(v: WebView?, cb: ValueCallback<Array<Uri>>?, p: FileChooserParams?): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = cb
                return try {
                    startActivityForResult(p!!.createIntent(), 7)
                    true
                } catch (_: Exception) {
                    fileCb = null
                    false
                }
            }
        }
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 7) {
            fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            fileCb = null
        } else {
            super.onActivityResult(requestCode, resultCode, data)
        }
    }

    override fun onDestroy() {
        stt?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }

    inner class Bridge {
        @JavascriptInterface
        fun listen(lang: String) = runOnUiThread {
            if (!SpeechRecognizer.isRecognitionAvailable(this@MainActivity)) {
                emit("error", "unavailable"); return@runOnUiThread
            }
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
                emit("error", "not-allowed"); return@runOnUiThread
            }
            stt?.destroy()
            val sr = SpeechRecognizer.createSpeechRecognizer(this@MainActivity)
            stt = sr
            sr.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) = emit("start")
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(buf: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onEvent(t: Int, p: Bundle?) {}
                override fun onError(e: Int) = emit(
                    "error",
                    when (e) {
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "no-speech"
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "not-allowed"
                        else -> "error $e"
                    }
                )
                override fun onResults(r: Bundle?) = emit(
                    "final", r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                )
                override fun onPartialResults(r: Bundle?) = emit(
                    "partial", r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                )
            })
            sr.startListening(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
                    .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            )
        }

        @JavascriptInterface
        fun stopListen() = runOnUiThread { stt?.cancel() }

        @JavascriptInterface
        fun speak(text: String, lang: String) = runOnUiThread {
            val t = tts
            if (t == null || !ttsReady) { emit("tts-end"); return@runOnUiThread }
            t.setLanguage(Locale.forLanguageTag(lang))
            t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) = emit("tts-start")
                override fun onDone(id: String?) = emit("tts-end")
                override fun onError(id: String?) = emit("tts-end")
            })
            t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u")
        }

        @JavascriptInterface
        fun stopSpeak() = runOnUiThread { tts?.stop() }

        @JavascriptInterface
        fun callName(name: String): String {
            if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return "NOPERM"
            val c = contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
                arrayOf("%" + name + "%"),
                null
            ) ?: return ""
            c.use { return if (it.moveToFirst()) (it.getString(0) ?: "") else "" }
        }

        @JavascriptInterface
        fun openApp(name: String): Boolean {
            val pm = packageManager
            val q = name.trim().lowercase()
            val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            val hit = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }
                ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
                ?: return false
            val i = pm.getLaunchIntentForPackage(hit.activityInfo.packageName) ?: return false
            runOnUiThread { startActivity(i) }
            return true
        }

        @JavascriptInterface
        fun alarm(h: Int, m: Int, label: String) = runOnUiThread {
            try {
                startActivity(
                    Intent(AlarmClock.ACTION_SET_ALARM)
                        .putExtra(AlarmClock.EXTRA_HOUR, h)
                        .putExtra(AlarmClock.EXTRA_MINUTES, m)
                        .putExtra(AlarmClock.EXTRA_MESSAGE, label)
                )
            } catch (_: Exception) {}
        }

        @JavascriptInterface
        fun timer(sec: Int, label: String) = runOnUiThread {
            try {
                startActivity(
                    Intent(AlarmClock.ACTION_SET_TIMER)
                        .putExtra(AlarmClock.EXTRA_LENGTH, sec)
                        .putExtra(AlarmClock.EXTRA_MESSAGE, label)
                )
            } catch (_: Exception) {}
        }

        @JavascriptInterface
        fun flash(on: Boolean): Boolean = try {
            val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            cm.setTorchMode(cm.cameraIdList[0], on)
            true
        } catch (_: Exception) {
            false
        }

        @JavascriptInterface
        fun volume(dir: String) = runOnUiThread {
            val a = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val d = when (dir) {
                "up" -> AudioManager.ADJUST_RAISE
                "down" -> AudioManager.ADJUST_LOWER
                else -> AudioManager.ADJUST_TOGGLE_MUTE
            }
            a.adjustStreamVolume(AudioManager.STREAM_MUSIC, d, AudioManager.FLAG_SHOW_UI)
        }

        @JavascriptInterface
        fun settings(kind: String) = runOnUiThread {
            val act = when (kind) {
                "wifi" -> Settings.ACTION_WIFI_SETTINGS
                "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
                "display" -> Settings.ACTION_DISPLAY_SETTINGS
                "sound" -> Settings.ACTION_SOUND_SETTINGS
                "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
                else -> Settings.ACTION_SETTINGS
            }
            try { startActivity(Intent(act)) } catch (_: Exception) {}
        }

        @JavascriptInterface
        fun battery(): String {
            val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val l = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val s = b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            val st = b?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            val ch = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
            return (if (l >= 0) (l * 100 / s).toString() + "%" else "unknown") + (if (ch) " (charging)" else "")
        }
    }
}
